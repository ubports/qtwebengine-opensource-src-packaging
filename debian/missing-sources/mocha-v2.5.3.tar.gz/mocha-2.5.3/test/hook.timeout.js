before(function(done){
  this.timeout(100);
  setTimeout(done, 50);
})

it('should work', function(done) {
  done();
});
