test('pass', function() {
  // pass
});
